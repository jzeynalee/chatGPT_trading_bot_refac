# chatGPT_trading_bot_refac
this is a refactored version of my bot, created on 20250710.
