
from modules.signalChecker import SignalChecker  

def check_signals():  

      signal_checker = SignalChecker.get_instance()  
      signal_checker.check_signals()  

